# DLS AI Bot (1-bosqich: skelet)

Samsung S20+ da o'rnatiladigan Android ilova. Bu bosqichda ilova faqat **quvur to'g'ri ishlashini** tekshiradi:

- ekranni real vaqtda oladi (MediaProjection, ~15 FPS, 1/3 o'lcham),
- ekranga sun'iy bosish yuboradi (Accessibility, root kerak emas),
- DLS ustida suzuvchi panel ko'rsatadi: FPS, kadr o'lchami, `Bot`, `Tap`, `✕`.

O'yin mantiqi (menyu boti, to'pga yugurish, zarba) hali yo'q. U 2-bosqich.

> Muhim: bu kod mening muhitimda **kompilyatsiya qilinmagan** (Android SDK yo'q edi). Birinchi yig'ishda kichik xato chiqsa, xato matnini menga yuboring, tuzataman.

## APK yig'ish

### A) Android Studio (kompyuterda, eng oson)
1. Android Studio ni oching: **File → Open** → shu `dls-ai-bot` papkasi.
2. Gradle sinxronlashini kuting (internet kerak).
3. **Build → Build APK(s)**. Tayyor fayl: `app/build/outputs/apk/debug/app-debug.apk`.

### B) GitHub Actions (kompyutersiz yig'ish)
1. GitHub'da yangi repo oching va shu papka ichidagi hamma fayllarni (`.github` papkasi bilan) yuklang.
2. **Actions** bo'limida `Build APK` ishga tushadi (yoki **Run workflow**).
3. Tugagach, natijadagi **dls-ai-bot-apk** artefaktini yuklab oling.

## Telefonga o'rnatish va sozlash

1. `app-debug.apk` ni telefonga ko'chiring va o'rnating ("noma'lum manbalardan o'rnatish" ruxsatini bering).
2. Ilovani oching va 1-qadamni bajaring: **boshqa ilovalar ustida ko'rsatish** ruxsati.
3. 2-qadam: Accessibility → **DLS AI Bot** ni yoqing.
   - Tugma kulrang bo'lib yoqilmasa (Android 13+ da APK dan o'rnatilgan ilovalarda shunday): **Sozlamalar → Ilovalar → DLS AI Bot → ⋮ (yuqori o'ng burchak) → Cheklangan sozlamalarga ruxsat berish**, so'ng yana urinib ko'ring.
4. 3-qadam: **Botni ishga tushirish** → ekranni yozishga ruxsat. Android 14 da **"Butun ekran"** variantini tanlang.
5. DLS 26 ni oching. Ekran burchagida panel paydo bo'ladi.

## Tekshiruv ro'yxati (1-bosqich tayyor degani)

- [ ] Panelda FPS 0 emas (taxminan 10-15).
- [ ] `Access: ok` yozuvi bor.
- [ ] `Tap` tugmasi ekran markaziga bosish yuboradi (masalan, DLS menyusida markazdagi tugma bosiladi).
- [ ] O'yin ichida va menyuda `Yorqinlik` qiymati o'zgaradi (kadrlar haqiqiy ekanini bildiradi). Doim 0 bo'lsa, o'yin ekranni yozishni to'sib qo'ygan bo'lishi mumkin; shuni menga ayting.

## Fayllar

| Fayl | Vazifasi |
|---|---|
| `MainActivity.kt` | Ruxsatlar va ishga tushirish ekrani |
| `ScreenCaptureService.kt` | Ekranni olish, panelni va Brain'ni boshqarish |
| `BotAccessibilityService.kt` | `tap`, `swipe`, ko'p barmoqli `gesture` |
| `Overlay.kt` | Suzuvchi panel |
| `Brain.kt` | Qaror qabul qilish (hozircha bo'sh `step`) |
| `Core.kt` | `FrameBus` (so'nggi kadr), `Vision` (rang bo'yicha qidirish yordamchilari) |

## Keyingi bosqichlar

2. Menyu boti: Career'da o'yinni boshlash, reklama/mukofotlarni o'tkazish, keyin qoidaga asoslangan o'yin (to'pga yugurish, zarba, himoya).
3. Imitatsion o'rganish: sizning o'yiningizdan yozib olingan ma'lumot bilan kichik model, `.tflite` sifatida telefonda.

## Ogohlantirishlar

- Faqat **offline / Career** rejimida ishlating. Onlayn rejimda bot akkaunt bloklanishiga olib kelishi mumkin.
- Google Play Accessibility'dan bunday foydalanishni qabul qilmaydi, shuning uchun ilova faqat shaxsiy APK sifatida.
