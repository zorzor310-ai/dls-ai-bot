package uz.dlsbot

import android.content.Context
import android.graphics.Bitmap
import android.util.DisplayMetrics
import android.view.WindowManager

/** Eng so'nggi ekran kadri. Capture oqimi yozadi, Brain o'qiydi. */
object FrameBus {
    @Volatile var latest: Bitmap? = null
    @Volatile var frames: Long = 0
    @Volatile var captureW: Int = 0
    @Volatile var captureH: Int = 0

    fun publish(b: Bitmap) {
        latest = b
        frames++
    }

    fun clear() {
        latest = null
        frames = 0
    }
}

object ScreenInfo {
    /** Hozirgi (aylantirilgan holatdagi) haqiqiy ekran o'lchami, piksellarda. */
    @Suppress("DEPRECATION")
    fun real(ctx: Context): DisplayMetrics {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return dm
    }
}

/** Kompyuter ko'rishi uchun oddiy yordamchilar. 2-bosqichda shu yerga to'p/o'yinchi aniqlash qo'shiladi. */
object Vision {

    /** Kadrning o'rtacha yorqinligi (0..255). Oqim haqiqatan ishlayotganini tekshirish uchun. */
    fun meanBrightness(b: Bitmap, step: Int = 8): Int {
        var sum = 0L
        var n = 0
        var y = 0
        while (y < b.height) {
            var x = 0
            while (x < b.width) {
                val p = b.getPixel(x, y)
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val bl = p and 0xFF
                sum += (r + g + bl) / 3
                n++
                x += step
            }
            y += step
        }
        return if (n == 0) 0 else (sum / n).toInt()
    }

    /** Rangi sharti bo'yicha mos piksellarning markazi (kadr koordinatasida), topilmasa null. */
    fun findCentroid(
        b: Bitmap,
        step: Int = 2,
        match: (r: Int, g: Int, b: Int) -> Boolean
    ): Pair<Int, Int>? {
        var sx = 0L
        var sy = 0L
        var n = 0
        var y = 0
        while (y < b.height) {
            var x = 0
            while (x < b.width) {
                val p = b.getPixel(x, y)
                if (match((p shr 16) and 0xFF, (p shr 8) and 0xFF, p and 0xFF)) {
                    sx += x
                    sy += y
                    n++
                }
                x += step
            }
            y += step
        }
        return if (n < 3) null else Pair((sx / n).toInt(), (sy / n).toInt())
    }

    /** Kichraytirilgan kadr koordinatasini haqiqiy ekran koordinatasiga o'giradi (bosish uchun). */
    fun toScreen(x: Int, y: Int, frame: Bitmap, screenW: Int, screenH: Int): Pair<Float, Float> =
        Pair(x * screenW / frame.width.toFloat(), y * screenH / frame.height.toFloat())
}
