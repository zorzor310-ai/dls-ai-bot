package uz.dlsbot

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlin.math.abs

/**
 * Siz o'zingiz o'ynab turganingizda ekran kadrlarini galereyaga (Pictures/DLSBot) saqlaydi.
 * Ekran sezilarli o'zgargandagina saqlaydi (bir xil kadrlarni takrorlamaydi). Eng ko'pi MAX ta.
 * Kadrlar faqat telefoningizda qoladi, internetga yuborilmaydi.
 */
class Collector(private val ctx: Context, private val report: (String) -> Unit) {

    companion object {
        private const val MAX = 80
        private const val EVERY_MS = 1500L
        private const val CHANGE_THRESHOLD = 6
    }

    @Volatile
    var on: Boolean = false
        private set

    @Volatile
    var saved: Int = 0
        private set

    private var thread: Thread? = null
    private var lastSig: IntArray? = null
    private val session = System.currentTimeMillis()
    private var failedOnce = false

    fun toggle(): Boolean {
        if (on) stop() else start()
        return on
    }

    private fun start() {
        saved = 0
        lastSig = null
        failedOnce = false
        on = true
        thread = Thread({ loop() }, "collector").also {
            it.isDaemon = true
            it.start()
        }
    }

    fun stop() {
        on = false
        thread?.interrupt()
        thread = null
    }

    private fun loop() {
        try {
            while (on && saved < MAX) {
                val f = FrameBus.latest
                if (f != null) {
                    val sig = signature(f)
                    if (changed(lastSig, sig)) {
                        lastSig = sig
                        if (save(f)) {
                            saved++
                        } else if (!failedOnce) {
                            failedOnce = true
                            report("Saqlab bo'lmadi")
                        }
                    }
                }
                Thread.sleep(EVERY_MS)
            }
            if (saved >= MAX) report("To'ldi: $MAX ta kadr")
        } catch (_: InterruptedException) {
            // to'xtatildi
        } finally {
            on = false
        }
    }

    /** Kadrning 16x9 katakli yorqinlik "barmoq izi" (o'zgarishni topish uchun). */
    private fun signature(b: Bitmap): IntArray {
        val s = IntArray(16 * 9)
        var i = 0
        for (gy in 0 until 9) {
            for (gx in 0 until 16) {
                val x = ((gx * 2 + 1) * b.width / 32).coerceIn(0, b.width - 1)
                val y = ((gy * 2 + 1) * b.height / 18).coerceIn(0, b.height - 1)
                val p = b.getPixel(x, y)
                s[i++] = (((p shr 16) and 0xFF) + ((p shr 8) and 0xFF) + (p and 0xFF)) / 3
            }
        }
        return s
    }

    private fun changed(a: IntArray?, b: IntArray): Boolean {
        if (a == null) return true
        var d = 0
        for (i in b.indices) d += abs(a[i] - b[i])
        return d / b.size > CHANGE_THRESHOLD
    }

    private fun save(bmp: Bitmap): Boolean {
        return try {
            val name = "dls_%d_%03d.jpg".format(session, saved)
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= 29) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DLSBot")
                }
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return false
            ctx.contentResolver.openOutputStream(uri)?.use {
                bmp.compress(Bitmap.CompressFormat.JPEG, 88, it)
            } ?: return false
            true
        } catch (e: Exception) {
            false
        }
    }
}
