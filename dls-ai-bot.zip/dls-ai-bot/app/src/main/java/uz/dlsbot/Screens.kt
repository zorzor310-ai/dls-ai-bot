package uz.dlsbot

import android.graphics.Bitmap

/** Rang sharti: (r, g, b) 0..255 */
typealias RgbTest = (Int, Int, Int) -> Boolean

object Colors {
    /** "CAREER" sarlavhasining qizil rangi */
    val red: RgbTest = { r, g, b -> r > 170 && g < 90 && b < 110 }

    /** "SCENARIO" va "DREAM LEAGUE LIVE" sarlavhalarining havorang tusi */
    val cyan: RgbTest = { r, g, b -> r < 80 && g > 150 && b > 210 }
}

/** Kadrning (fx, fy) nuqtasi (0..1 nisbatda) rangi shartga mosligini tekshiradi. */
class Check(val fx: Float, val fy: Float, val test: RgbTest)

/**
 * Bitta o'yin ekrani: nomi, uni tanish uchun rang belgilari va (kerak bo'lsa) shu yerda bosiladigan nuqta.
 * Yangi ekran qo'shish uchun shunchaki yana bitta ScreenDef yoziladi va `Screens.all` ga qo'shiladi.
 */
class ScreenDef(
    val name: String,
    val checks: List<Check>,
    val minMatch: Float = 0.85f,
    /** Bosiladigan nuqta (ekran o'lchamining 0..1 qismi), yo'q bo'lsa bot faqat tanib turadi. */
    val tapX: Float? = null,
    val tapY: Float? = null,
    val cooldownMs: Long = 3000
)

object Screens {

    /**
     * DLS 26 bosh menyu. 1280x576 skrinshotdan o'lchangan:
     *  - chap yuqoridagi CAREER sarlavhasi qizil,
     *  - o'ngdagi SCENARIO sarlavhasi va chap o'rtadagi DREAM LEAGUE LIVE sarlavhasi havorang.
     * Bosish nuqtasi: Career kartasining ichi (chap yuqori karta, sarlavha ostida).
     */
    val MAIN_MENU = ScreenDef(
        name = "Bosh menyu",
        checks = buildList {
            for (x in listOf(0.20f, 0.23f, 0.26f, 0.29f, 0.32f, 0.35f, 0.38f, 0.41f)) {
                add(Check(x, 0.151f, Colors.red))
            }
            for (x in listOf(0.62f, 0.64f, 0.66f, 0.68f)) {
                add(Check(x, 0.151f, Colors.cyan))
            }
            for (x in listOf(0.30f, 0.34f, 0.38f, 0.42f)) {
                add(Check(x, 0.497f, Colors.cyan))
            }
        },
        tapX = 0.30f,
        tapY = 0.34f
    )

    val all: List<ScreenDef> = listOf(MAIN_MENU)

    /** Kadr qaysi ekranga mos kelishini topadi, hech biriga mos kelmasa null. */
    fun detect(frame: Bitmap): ScreenDef? {
        var best: ScreenDef? = null
        var bestScore = 0f
        for (def in all) {
            var ok = 0
            for (c in def.checks) {
                val rgb = sample(frame, c.fx, c.fy)
                if (c.test((rgb shr 16) and 0xFF, (rgb shr 8) and 0xFF, rgb and 0xFF)) ok++
            }
            val score = ok.toFloat() / def.checks.size
            if (score >= def.minMatch && score > bestScore) {
                best = def
                bestScore = score
            }
        }
        return best
    }

    /** Nuqta atrofidagi 3x3 pikselning o'rtacha rangi (bitta shovqinli piksel xato qilmasligi uchun). */
    private fun sample(b: Bitmap, fx: Float, fy: Float): Int {
        val cx = (fx * b.width).toInt()
        val cy = (fy * b.height).toInt()
        var r = 0
        var g = 0
        var bl = 0
        var n = 0
        for (dy in -1..1) {
            for (dx in -1..1) {
                val x = (cx + dx).coerceIn(0, b.width - 1)
                val y = (cy + dy).coerceIn(0, b.height - 1)
                val p = b.getPixel(x, y)
                r += (p shr 16) and 0xFF
                g += (p shr 8) and 0xFF
                bl += p and 0xFF
                n++
            }
        }
        return ((r / n) shl 16) or ((g / n) shl 8) or (bl / n)
    }
}
