package uz.dlsbot

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val reqCapture = 100
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "DLS AI Bot"
            textSize = 24f
        })
        info = TextView(this).apply {
            textSize = 16f
            setPadding(0, pad, 0, pad)
        }
        root.addView(info)

        addButton(root, "1. Boshqa ilovalar ustida ko'rsatishga ruxsat") { openOverlaySettings() }
        addButton(root, "2. Accessibility xizmatini yoqish") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton(root, "3. Botni ishga tushirish") { requestCapture() }
        addButton(root, "To'xtatish") {
            startService(Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP))
        }

        root.addView(TextView(this).apply {
            text = "3-qadamdan keyin DLS ni oching. Ekran ustida kichik panel (FPS, Bot, Tap, ✕) paydo bo'ladi."
            textSize = 14f
            setPadding(0, pad, 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        val overlayOk = Settings.canDrawOverlays(this)
        val a11yOk = BotAccessibilityService.instance != null
        val botOn = ScreenCaptureService.running
        info.text = "1) Overlay ruxsati: ${mark(overlayOk)}\n" +
            "2) Accessibility: ${mark(a11yOk)}\n" +
            "3) Xizmat: ${if (botOn) "ishlayapti" else "o'chiq"}"
    }

    private fun mark(ok: Boolean) = if (ok) "✔" else "✘"

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        })
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun requestCapture() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Avval 1-qadamni bajaring", Toast.LENGTH_LONG).show()
            return
        }
        if (BotAccessibilityService.instance == null) {
            Toast.makeText(this, "Avval 2-qadamni bajaring", Toast.LENGTH_LONG).show()
            return
        }
        val mgr = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mgr.createScreenCaptureIntent(), reqCapture)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqCapture) return
        if (resultCode != Activity.RESULT_OK || data == null) {
            Toast.makeText(this, "Ekranni yozishga ruxsat berilmadi", Toast.LENGTH_LONG).show()
            return
        }
        val svc = Intent(this, ScreenCaptureService::class.java)
            .setAction(ScreenCaptureService.ACTION_START)
            .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            .putExtra(ScreenCaptureService.EXTRA_DATA, data)
        startForegroundService(svc)
        Toast.makeText(this, "Ishga tushdi. DLS ni oching.", Toast.LENGTH_LONG).show()
    }
}
