package uz.dlsbot

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** O'yin ustida suzib turadigan boshqaruv paneli. Holat matnini sudrab joyini o'zgartirish mumkin. */
class Overlay(
    private val ctx: Context,
    private val onToggle: () -> Boolean,
    private val onTapTest: () -> Unit,
    private val onCollect: () -> Boolean,
    private val onClose: () -> Unit
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val root = LinearLayout(ctx)
    private val status = TextView(ctx)

    private val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 24
        y = 24
    }

    private var base = ""
    private var note = ""
    private var shown = false

    private val clearNote = Runnable {
        note = ""
        render()
    }

    fun show() {
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xCC000000.toInt())
        root.setPadding(12, 12, 12, 12)

        status.setTextColor(Color.WHITE)
        status.textSize = 11f
        status.text = "..."
        status.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x
                        startY = lp.y
                        touchX = e.rawX
                        touchY = e.rawY
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = startX + (e.rawX - touchX).toInt()
                        lp.y = startY + (e.rawY - touchY).toInt()
                        wm.updateViewLayout(root, lp)
                    }
                }
                return true
            }
        })
        root.addView(status)

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL

        val toggle = smallButton("▶ Bot")
        toggle.setOnClickListener {
            toggle.text = if (onToggle()) "⏸ Bot" else "▶ Bot"
        }
        val tap = smallButton("Tap")
        tap.setOnClickListener { onTapTest() }
        val rec = smallButton("📷")
        rec.setOnClickListener { rec.text = if (onCollect()) "⏹ 📷" else "📷" }
        val close = smallButton("✕")
        close.setOnClickListener { onClose() }

        row.addView(toggle)
        row.addView(tap)
        row.addView(rec)
        row.addView(close)
        root.addView(row)

        wm.addView(root, lp)
        shown = true
    }

    fun hide() {
        ui.removeCallbacksAndMessages(null)
        if (shown) {
            try {
                wm.removeView(root)
            } catch (_: Exception) {
            }
            shown = false
        }
    }

    fun setStatus(text: String) {
        ui.post {
            base = text
            render()
        }
    }

    /** Qisqa vaqtli xabar (3 soniya). */
    fun flash(msg: String) {
        ui.post {
            note = msg
            render()
            ui.removeCallbacks(clearNote)
            ui.postDelayed(clearNote, 3000)
        }
    }

    private fun render() {
        status.text = if (note.isEmpty()) base else "$base\n$note"
    }

    private fun smallButton(label: String): Button = Button(ctx).apply {
        text = label
        textSize = 11f
        minWidth = 0
        minHeight = 0
        setPadding(16, 4, 16, 4)
    }
}
