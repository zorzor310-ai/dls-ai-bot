package uz.dlsbot

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock

/**
 * Foreground xizmat: ekranni oladi (MediaProjection), suzuvchi panelni ko'rsatadi va Brain'ni boshqaradi.
 *
 * Kadr o'lchami: haqiqiy ekranning 1/SCALE qismi, har doim LANDSCAPE (DLS gorizontal o'ynaladi).
 * Ilova portrait holatda ishga tushirilsa ham, o'yin gorizontalga o'tganda kadr to'g'ri to'ladi.
 */
class ScreenCaptureService : Service() {

    companion object {
        const val ACTION_START = "uz.dlsbot.START"
        const val ACTION_STOP = "uz.dlsbot.STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"

        private const val CHANNEL_ID = "dlsbot"
        private const val NOTIF_ID = 1
        private const val SCALE = 3
        private const val MIN_FRAME_GAP_MS = 60L

        @Volatile
        var running: Boolean = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var captureThread: HandlerThread? = null
    private var overlay: Overlay? = null
    private var brain: Brain? = null
    private var collector: Collector? = null
    private var stopping = false
    private var lastFrameAt = 0L

    private val ticker = object : Runnable {
        var lastFrames = 0L
        override fun run() {
            val f = FrameBus.frames
            val fps = f - lastFrames
            lastFrames = f
            val a11y = if (BotAccessibilityService.instance != null) "ok" else "YO'Q"
            val bot = if (brain?.active == true) "ON" else "OFF"
            overlay?.setStatus(
                "FPS $fps  ${FrameBus.captureW}x${FrameBus.captureH}\n" +
                    "Access: $a11y  Bot: $bot\n" +
                    "Ekran: ${brain?.screenName ?: "-"}\n" +
                    "Bosishlar: ${brain?.taps ?: 0}" +
                    (if (collector?.on == true) "\nYig'ish: ${collector?.saved ?: 0}" else "")
            )
            main.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY

        // Android 5 soniya ichida startForeground chaqirilishini talab qiladi.
        goForeground()

        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        if (code != Activity.RESULT_OK || data == null) {
            shutdown()
            return START_NOT_STICKY
        }

        startCapture(code, data)

        brain = Brain(this) { msg -> overlay?.flash(msg) }.also { it.begin() }
        collector = Collector(this) { msg -> overlay?.flash(msg) }
        overlay = Overlay(
            this,
            { brain?.toggle() ?: false },
            { brain?.testTap() },
            { collector?.toggle() ?: false },
            { shutdown() }
        ).also { it.show() }

        running = true
        main.post(ticker)
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "DLS AI Bot", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("DLS AI Bot ishlayapti")
            .setContentText("To'xtatish uchun bosing")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(stopIntent)
            .addAction(android.R.drawable.ic_delete, "To'xtatish", stopIntent)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun startCapture(code: Int, data: Intent) {
        val mgr = getSystemService(MediaProjectionManager::class.java)
        val p = mgr.getMediaProjection(code, data)
        projection = p

        val thread = HandlerThread("capture").also { it.start() }
        captureThread = thread
        val handler = Handler(thread.looper)

        // Android 14 da createVirtualDisplay dan oldin callback ro'yxatdan o'tkazilishi shart.
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { shutdown() }
            }
        }, handler)

        val dm = ScreenInfo.real(this)
        val longSide = maxOf(dm.widthPixels, dm.heightPixels)
        val shortSide = minOf(dm.widthPixels, dm.heightPixels)
        val w = longSide / SCALE
        val h = shortSide / SCALE
        FrameBus.captureW = w
        FrameBus.captureH = h

        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ rd ->
            val img = try {
                rd.acquireLatestImage()
            } catch (e: Exception) {
                null
            }
            if (img != null) {
                try {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastFrameAt >= MIN_FRAME_GAP_MS) {
                        lastFrameAt = now
                        FrameBus.publish(toBitmap(img))
                    }
                } finally {
                    img.close()
                }
            }
        }, handler)
        reader = r

        display = p.createVirtualDisplay(
            "dlsbot", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, handler
        )
    }

    private fun toBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * image.width
        val wide = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
        )
        wide.copyPixelsFromBuffer(plane.buffer)
        if (rowPadding == 0) return wide
        val cropped = Bitmap.createBitmap(wide, 0, 0, image.width, image.height)
        wide.recycle()
        return cropped
    }

    private fun shutdown() {
        if (stopping) return
        stopping = true
        running = false
        main.removeCallbacks(ticker)
        brain?.stop()
        brain = null
        collector?.stop()
        collector = null
        overlay?.hide()
        overlay = null
        display?.release()
        display = null
        reader?.close()
        reader = null
        try {
            projection?.stop()
        } catch (_: Exception) {
        }
        projection = null
        captureThread?.quitSafely()
        captureThread = null
        FrameBus.clear()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}
