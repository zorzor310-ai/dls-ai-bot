package uz.dlsbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * Bitta barmoq harakati: (x1,y1) dan (x2,y2) ga, startMs dan boshlab durMs davomida.
 * x1==x2 va y1==y2 bo'lsa oddiy bosish (yoki ushlab turish).
 */
data class Touch(
    val x1: Float, val y1: Float,
    val x2: Float = x1, val y2: Float = y1,
    val startMs: Long = 0, val durMs: Long = 60
)

/** Ekranga sun'iy bosish yuboradigan xizmat. Root kerak emas. */
class BotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: BotAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    fun tap(x: Float, y: Float, durMs: Long = 60): Boolean =
        gesture(listOf(Touch(x, y, durMs = durMs)))

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durMs: Long = 200): Boolean =
        gesture(listOf(Touch(x1, y1, x2, y2, durMs = durMs)))

    /**
     * Bir vaqtda bir nechta barmoq (masalan: chap bosh barmoq joystikda, o'ng bosh barmoq zarba tugmasida).
     * Eslatma: yangi gesture yuborilsa, oldingisi tugamagan bo'lsa bekor bo'lishi mumkin.
     */
    fun gesture(touches: List<Touch>): Boolean {
        if (touches.isEmpty()) return false
        val builder = GestureDescription.Builder()
        for (t in touches) {
            val path = Path().apply {
                moveTo(t.x1, t.y1)
                if (t.x1 != t.x2 || t.y1 != t.y2) lineTo(t.x2, t.y2)
            }
            builder.addStroke(GestureDescription.StrokeDescription(path, t.startMs, t.durMs))
        }
        return dispatchGesture(builder.build(), null, null)
    }
}
