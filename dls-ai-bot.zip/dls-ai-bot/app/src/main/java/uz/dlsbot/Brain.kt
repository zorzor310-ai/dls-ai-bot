package uz.dlsbot

import android.content.Context
import android.graphics.Bitmap

/**
 * Qaror qabul qiluvchi qism.
 * 1-bosqichda faqat quvur (pipeline) ishlayotganini tekshiradi: kadr oladi, yorqinlikni hisoblaydi.
 * 2-bosqichda step() ichiga menyu boti va qoidaga asoslangan o'yin mantiqi qo'shiladi.
 */
class Brain(private val ctx: Context, private val report: (String) -> Unit) {

    @Volatile
    var active: Boolean = false
        private set

    @Volatile
    var brightness: Int = 0
        private set

    private var thread: Thread? = null

    fun toggle(): Boolean {
        if (active) stop() else start()
        return active
    }

    private fun start() {
        active = true
        thread = Thread({ loop() }, "brain").also {
            it.isDaemon = true
            it.start()
        }
    }

    fun stop() {
        active = false
        thread?.interrupt()
        thread = null
    }

    private fun loop() {
        try {
            while (active) {
                FrameBus.latest?.let { step(it) }
                Thread.sleep(100)
            }
        } catch (_: InterruptedException) {
            // to'xtatildi
        }
    }

    private fun step(frame: Bitmap) {
        brightness = Vision.meanBrightness(frame)
        // TODO 2-bosqich: ekran turini aniqlash (menyu / o'yin), keyin tegishli harakat.
    }

    /** Ekran markaziga bitta bosish yuboradi. Accessibility ishlayotganini tekshirish uchun. */
    fun testTap() {
        val svc = BotAccessibilityService.instance
        if (svc == null) {
            report("Accessibility yoqilmagan")
            return
        }
        val dm = ScreenInfo.real(ctx)
        val ok = svc.tap(dm.widthPixels / 2f, dm.heightPixels / 2f)
        report(if (ok) "Bosish yuborildi" else "Bosish rad etildi")
    }
}
