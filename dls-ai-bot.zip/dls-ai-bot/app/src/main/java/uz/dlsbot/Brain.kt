package uz.dlsbot

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock

/**
 * Qaror qabul qiluvchi qism.
 *
 * Ekran tanish (qaysi oynadaligini aniqlash) doim ishlaydi va panelda ko'rinadi.
 * Harakat (bosish) faqat `active` yoqilganda bajariladi.
 * Hozir: bosh menyuda Career kartasini bosadi. Keyingi ekranlar skrinshotlar bilan qo'shiladi.
 */
class Brain(private val ctx: Context, private val report: (String) -> Unit) {

    /** true bo'lsa bot harakat qiladi (Bot tugmasi). */
    @Volatile
    var active: Boolean = false
        private set

    @Volatile
    var screenName: String = "-"
        private set

    @Volatile
    var taps: Int = 0
        private set

    @Volatile
    private var running = false
    private var thread: Thread? = null

    private var lastSeen: ScreenDef? = null
    private var seenCount = 0
    private var lastActionAt = 0L

    /** Ekran tanishni ishga tushiradi (bosishlar hali o'chiq). */
    fun begin() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "brain").also {
            it.isDaemon = true
            it.start()
        }
    }

    /** Bot tugmasi: harakatlarni yoqadi yoki o'chiradi. */
    fun toggle(): Boolean {
        active = !active
        if (active) {
            seenCount = 0
            lastSeen = null
            lastActionAt = 0L
        }
        return active
    }

    fun stop() {
        active = false
        running = false
        thread?.interrupt()
        thread = null
    }

    private fun loop() {
        try {
            while (running) {
                FrameBus.latest?.let { step(it) }
                Thread.sleep(100)
            }
        } catch (_: InterruptedException) {
            // to'xtatildi
        }
    }

    private fun step(frame: Bitmap) {
        val def = Screens.detect(frame)
        screenName = def?.name ?: "noma'lum"

        if (!active) return
        if (def == null) {
            lastSeen = null
            seenCount = 0
            return
        }

        // Bir xil ekran 3 ketma-ket kadrda (~0.3 soniya) ko'ringandagina harakat qilamiz
        // (o'tish animatsiyasi vaqtida bosib yubormaslik uchun).
        if (def === lastSeen) seenCount++ else {
            lastSeen = def
            seenCount = 1
        }
        if (seenCount < 3) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastActionAt < def.cooldownMs) return

        val fx = def.tapX
        val fy = def.tapY
        if (fx == null || fy == null) return

        val svc = BotAccessibilityService.instance
        if (svc == null) {
            report("Accessibility yoqilmagan")
            return
        }

        // DLS gorizontal: uzun tomon = x, qisqa tomon = y.
        val dm = ScreenInfo.real(ctx)
        val x = fx * maxOf(dm.widthPixels, dm.heightPixels)
        val y = fy * minOf(dm.widthPixels, dm.heightPixels)
        if (svc.tap(x, y)) {
            taps++
            lastActionAt = now
            report("${def.name}: bosildi")
        }
    }

    /** Ekran markaziga bitta bosish yuboradi. Accessibility ishlayotganini tekshirish uchun. */
    fun testTap() {
        val svc = BotAccessibilityService.instance
        if (svc == null) {
            report("Accessibility yoqilmagan")
            return
        }
        val dm = ScreenInfo.real(ctx)
        val ok = svc.tap(dm.widthPixels / 2f, dm.heightPixels / 2f)
        report(if (ok) "Bosish yuborildi" else "Bosish rad etildi")
    }
}
