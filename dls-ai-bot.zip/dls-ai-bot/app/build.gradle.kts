plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "uz.dlsbot"
    compileSdk = 34

    defaultConfig {
        applicationId = "uz.dlsbot"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "0.3"
    }

    // Doimiy imzo kaliti: keyingi versiyalarni eskisining ustiga o'rnatish uchun.
    // (Har yig'ishda tasodifiy kalit ishlatilsa, Android yangilashni rad etadi.)
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// 1-bosqichda hech qanday tashqi kutubxona kerak emas.
// 3-bosqichda shu yerga TensorFlow Lite qo'shiladi.
dependencies {
}
